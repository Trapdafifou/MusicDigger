<header>
    <a href="http://musicdigger.fr/"><img class="logo" src="./images/logo.png"></a>
    
</header>

<?php

include( 'navIndex.php' );
?>