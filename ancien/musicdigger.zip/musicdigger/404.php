<?php

header("Location: http://musicdigger.fr/");

?>